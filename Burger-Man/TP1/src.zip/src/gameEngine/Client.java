package gameEngine;

import java.util.Random;

public class Client {
    public static final GameEngine ENGINE = new GameEngine();
    public static double PLAYER_SPEED = 1, PLAYER_SPEED_BUFFER = 0;
    public static final Random RANDOM = new Random();

    public static void main(String[] args) {

    }
}